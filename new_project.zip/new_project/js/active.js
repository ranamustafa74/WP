$(document).ready(function(){
  $('.counter').counterUp({
            delay: 10,
            time: 1000
        });
 /* START BOX SLIDER */   
    
$('.bxslider').bxSlider({
  minSlides: 3,
  maxSlides: 3,
  slideWidth: 350,
  slideMargin: 40 ,
  minSlides: 2,
  responsive:true
});
    
	
 /*END BOX SLIDER */  
	

    /*Start Slider */

    //Function to animate slider captions 
	function doAnimations( elems ) {
		//Cache the animationend event in a variable
		var animEndEv = 'webkitAnimationEnd animationend';
		
		elems.each(function () {
			var $this = $(this),
				$animationType = $this.data('animation');
			$this.addClass($animationType).one(animEndEv, function () {
				$this.removeClass($animationType);
			});
		});
	}
	
	//Variables on page load 
	var $myCarousel = $('#sg-carousel'),
		$firstAnimatingElems = $myCarousel.find('.item:first').find("[data-animation ^= 'animated']");
		
	//Initialize carousel 
	$myCarousel.carousel();
	
	//Animate captions in first slide on page load 
	doAnimations($firstAnimatingElems);
	
	//Pause carousel  
	$myCarousel.carousel('pause');
	
	
	//Other slides to be animated on carousel slide event 
	$myCarousel.on('slide.bs.carousel', function (e) {
		var $animatingElems = $(e.relatedTarget).find("[data-animation ^= 'animated']");
		doAnimations($animatingElems);
	});  
   
/*End The Slider */	
	
	
	/*Start Prjects Session*/
	$(".progects .buttons .filter ").click(function(){
		
		$(this).addClass("active").siblings().removeClass("active");
		
	});
	
	
	
	 $('#container').mixItUp();
	
	/*End Projects Session */
	/*End Slider */

$('.toggle-info').click(function(){
    
    $(this).toggleClass('selected').parent().next('.panel-body').slideToggle(50) ; 
    if($(this).hasClass('selected')){
    
    $(this).html('<i class="fa fa-minus"></i>') ;

    }
    else{
        
     $(this).html('<i class="fa fa-plus" aria-hidden="true"></i>') ;
    
    }
});
    });